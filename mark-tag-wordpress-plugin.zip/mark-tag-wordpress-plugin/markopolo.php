<?php
/*
 * Plugin Name: Markopolo.ai - MarkTag for WooCommerce
 * Plugin URI: https://www.markopolo.ai
 * Author: Markopolo.ai
 * Author URI: https://www.markopolo.ai
 * Version: 1.0.0
 * Description: Capture every event, & get back every lost audience from all channels. Seamlessly integrate MarkTag with WooCommerce to track all your conversions.
 * License:GPLv2 or later
 */


if (!defined('ABSPATH')) {
        exit; // Exit if accessed directly
}

// Check if WooCommerce is active before activating the plugin
function markopolo_check_woocommerce()
{
        if (!class_exists('WooCommerce')) {
                // WooCommerce is not installed, so don't activate the plugin
                deactivate_plugins(plugin_basename(__FILE__));
                wp_die('This plugin requires WooCommerce. Please install and activate WooCommerce to use this plugin.');
        }
}


// Hook the check into the activation process
register_activation_hook(__FILE__, 'markopolo_check_woocommerce');

require_once 'includes/helpers.php';
require_once 'includes/logger.php';

// // Load main plugin class
require_once 'includes/class-markopolo.php';
require_once 'includes/markopolo-events.php';
function enqueue_marktag_script()
{
        try {
                $logger = new Logger();
                $marktag_hostname = get_option('marktag_hostname');
                $marktag_script_id = get_option('marktag_script_id');

                if ($marktag_hostname && $marktag_script_id) {
                        $script1 = '<script id = "{{script_id}}">
window.mtrem = window.mtrem || [];  
function mtag(){mtrem.push(arguments)};
mtag("init", "https://{{hostname}}", {consent: true});
mtag("event", {type:"ViewContent"});
</script>';

                        // Replace placeholder with real hostname
                        $script1 = str_replace('{{hostname}}', $marktag_hostname, $script1);
                        $script1 = str_replace('{{script_id}}', $marktag_script_id, $script1);

                        // External async script 
                        $script2 = '<script id = "{{script_id}}" async type="text/javascript" src="https://{{hostname}}/script"></script>';

                        // Replace placeholder in external script url
                        $script2 = str_replace('{{hostname}}', $marktag_hostname, $script2);
                        $script2 = str_replace('{{script_id}}', $marktag_script_id, $script2);

                        // Output scripts 
                        echo $script1;
                        echo $script2;
                }

        } catch (Exception $e) {
                $logger->log($e->getMessage());
                return;
        }

}
add_action('wp_head', 'enqueue_marktag_script');

function activate_markopolo_plugin()
{
        try {
                $logger = new Logger();
                //Initialize plugin
                //This will create a menu in admin panel and register routes to listen to the request sent from Markopolo server
                $markopolo = new Markopolo();
                $markopolo->register();
                // Initialize class
                //This will listen to the event setup by admina and emitted by woocommerce and sent the event to markopolo server
                $events = new Markopolo_Events();
                $events->register();

                // add_action('wp_head', 'enqueue_marktag_script');


        } catch (Exception $e) {
                $logger->log($e->getMessage());
                return;
        }


}


activate_markopolo_plugin();