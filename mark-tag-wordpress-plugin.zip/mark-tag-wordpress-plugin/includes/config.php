<?php
define('MARKOPOLO_LOG_PATH', WP_CONTENT_DIR . '/plugins/mark-tag-wordpress-plugin/log/logger.log');
?>