<?php
include_once 'logger.php';
class Markopolo
{
        private $endpoint;
        private $logger;
        public function __construct()
        {
                $this->endpoint = 'wc/v3/markopoloApi';
                $this->logger = new Logger();
        }

        public function register()
        {
                try {

                        // Admin menu
                        add_action('admin_menu', [$this, 'register_menu']);

                        // Script endpoints
                        add_action('rest_api_init', [$this, 'register_endpoints']);
                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return;
                }

        }

        public function register_menu()
        {
                try {
                        $this->logger->log('\nRegistering menu');
                        add_menu_page('My Page Title', 'Markopolo.ai', 'manage_options', 'markopolo-main', [$this, 'my_markopolo_menu_main'], plugins_url('image/app.ico', __FILE__));
                        // add_submenu_page('markopolo-main', 'Home', 'Home', 'manage_options', 'my_markopolo_menu_home_page', 'my_markopolo_menu_home');
                        // add_submenu_page('markopolo-main', 'MarkTag', 'Mark tag', 'manage_options', 'my_markopolo_menu_marktag_page', 'my_markopolo_menu_marktag');
                        add_submenu_page('markopolo-main', 'Analytics', 'Analytics', 'manage_options', 'my_markopolo_menu_analytics_page', [$this, 'my_markopolo_menu_analytics']);
                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return;
                }

        }

        public function my_markopolo_menu_main()
        {
                include 'home.php';

        }

        public function my_markopolo_menu_analytics()
        {
                echo '<h2>Redirecting To Markopolo Analytics...</h2>
              <script>document.location.href = "https://app.markopolo.ai/marktag/list";</script>';
        }

        public function register_endpoints()
        {
                try {
                        //This endpoint will be used to add mark tag script to the website
                        $this->logger->log('\nRegistering endpoint');
                        register_rest_route(
                                $this->endpoint,
                                'add-script',
                                array(
                                        'callback' => [$this, 'add_script'],
                                        'methods' => 'POST',
                                        'permission_callback' => [$this, 'check_authentication']
                                )
                        );

                        register_rest_route(
                                $this->endpoint,
                                'set-brand-to-plugin',
                                array(
                                        'methods' => 'POST',
                                        'callback' => [$this, 'set_brand_to_plugin'],
                                        'permission_callback' => [$this, 'check_authentication']
                                )
                        );

                        register_rest_route(
                                $this->endpoint,
                                'disconnect-brand',
                                array(
                                        'methods' => 'POST',
                                        'callback' => [$this, 'disconnect_brand'],
                                        'permission_callback' => [$this, 'check_authentication']
                                )
                        );

                        register_rest_route(
                                $this->endpoint,
                                'remove-script',
                                array(
                                        'methods' => 'POST',
                                        'callback' => [$this, 'remove_script'],
                                        'permission_callback' => [$this, 'check_authentication']
                                )
                        );

                        register_rest_route(
                                $this->endpoint,
                                'update-events',
                                array(
                                        'methods' => 'POST',
                                        'callback' => [$this, 'update_marktag_event_webhooks'],
                                        'permission_callback' => [$this, 'check_authentication']

                                )
                        );

                        register_rest_route(
                                $this->endpoint,
                                'get-custom-domain',
                                array(
                                        'methods' => 'POST',
                                        'callback' => [$this, 'get_custom_domain'],
                                        'permission_callback' => [$this, 'check_authentication']
                                )
                        );
                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return;
                }


        }

        //This function will check if the API key sent from Markopolo server is valid or not
        public function check_authentication($request)
        {
                try {
                        $body = file_get_contents('php://input');
                        $body = json_decode($body, true);
                        $API_KEY = $body['apiKey'];
                        $HASHING_METHOD = $body['hashMethod'];

                        //Get encrypted API key and IV from database
                        $MARKOPOLO_ENCRYPTED_API_KEY = get_option('MARKOPOLO_API_KEY');
                        $MARKOPOLO_API_KEY_IV = get_option('MARKOPOLO_API_KEY_IV');

                        if(!$MARKOPOLO_ENCRYPTED_API_KEY || !$MARKOPOLO_API_KEY_IV)
                                return new WP_REST_Response(['success' => false, 'message' => 'Authentication failed', 'error' => 'API key not found', 'data' => []]);

                        //Decrypt the API key
                        $MARKOPOLO_API_HELPER = new Markolopolo_Helper();
                        $MARKOPOLO_DECRYPTED_KEY = $MARKOPOLO_API_HELPER->get_decrypted_api_key($MARKOPOLO_ENCRYPTED_API_KEY, $MARKOPOLO_API_KEY_IV);

                        if(!$MARKOPOLO_DECRYPTED_KEY)
                                return new WP_REST_Response(['success' => false, 'message' => 'Authentication failed', 'error' => 'API key not found', 'data' => []]);
                        //Match the hashed API key with the decrypted API key(Hashed)
                        $HASHED_API_KEY = hash($HASHING_METHOD, $API_KEY);
                        

                        if (hash_equals($HASHED_API_KEY, $MARKOPOLO_DECRYPTED_KEY)) {
                                return true;
                        } else {
                                return new WP_REST_Response(['success' => false, 'message' => 'Authentication failed', 'error' => 'Invalid API key', 'data' => []]);
                        }
                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return new WP_REST_Response(['success' => false, 'message' => 'Authentication failed', 'error' => 'Something went wrong', 'data' => []]);
                }

        }

        //This function will add mark tag script to the website that is being created by user from markopolo webiste
        public function add_script($request)
        {

                try {
                        $body = file_get_contents('php://input');
                        $body = json_decode($body, true);

                        $script = $body['markTagData'];

                        update_option('marktag_hostname', $script['hostname']);
                        update_option('marktag_script_id', $script['scriptId']);

                        $data = ['success' => true, 'message' => 'Script added successfully', 'error' => '', 'data' => []];
                        return new WP_REST_Response($data);



                } catch (Exception $e) {

                        return new WP_REST_Response(['success' => false, 'message' => 'Something went wrong while adding script', 'error' => $e->getMessage()]);

                }

        }

        //This function will remove mark tag script from the website when user clicks on remove script button on markopolo website
        public function remove_script($request)
        {
                try {
                        $body = file_get_contents('php://input');
                        $body = json_decode($body, true);

                        delete_option('custom_script_mark');

                        $data = ['success' => true, 'message' => 'Script removed successfully', 'error' => '', 'data' => []];
                        return new WP_REST_Response($data);



                } catch (Exception $e) {

                        return new WP_REST_Response(['success' => false, 'message' => 'Something went wrong while removing script', 'error' => $e->getMessage()]);

                }
        }

        //This will set brand name to the plugin
        public function set_brand_to_plugin($request)
        {
                try {
                        $body = file_get_contents('php://input');
                        $body = json_decode($body, true);

                        //Gen API Key
                        $gen_api_key = bin2hex(random_bytes(16));

                        //Hash key with SHA256 
                        $hashed_key = hash('sha256', $gen_api_key);


                        update_option('brandId', $body['brandName']);
                        $data = ['success' => true, 'message' => 'Brand set successfully', 'error' => '', 'data' => []];
                        return new WP_REST_Response($data);

                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return new WP_REST_Response(['success' => false, 'message' => 'Something went wrong while setting brand', 'error' => $e->getMessage()]);

                }
        }

        //This function will update the events that are being setup by admin
        //So that function will listen to those events and send the event to markopolo server
        public function update_marktag_event_webhooks($request)
        {
                try {
                        $body = file_get_contents('php://input');
                        $body = json_decode($body, true);
                        $events = $body['events'];
                        $condition = $body['condition'];
                        $error = [];
                        foreach ($events as $event) {
                                if ($event == 'AddToCart' || $event == 'Purchase' || $event == 'ViewContent' || $event == 'AddPaymentInfo' || $event == 'BeginCheckout') {
                                        if ($condition == 'add')
                                                update_option($event, true);
                                        else if ($condition == 'remove')
                                                update_option($event, false);
                                } else {
                                        $error . array_push(['error' => "Invalid Event name $event", 'message' => "Invalid Event name $event"]);
                                }
                        }

                        if (!empty($error)) {
                                $error_res = [
                                        'success' => false,
                                        'message' => 'Some events are not updated',
                                        'errors' => $error
                                ];
                                return new WP_REST_Response($error_res);
                        }


                        $active_events = [];
                        if (get_option('AddToCart'))
                                array_push($active_events, 'AddToCart');
                        if (get_option('Purchase'))
                                array_push($active_events, 'Purchase');
                        if (get_option('ViewContent'))
                                array_push($active_events, 'ViewContent');
                        if (get_option('AddPaymentInfo'))
                                array_push($active_events, 'AddPaymentInfo');
                        if (get_option('BeginCheckout'))
                                array_push($active_events, 'BeginCheckout');

                        $success_res = [
                                'success' => true,
                                'message' => 'Events updated successfully',
                                'active_events' => $active_events
                        ];
                        return new WP_REST_Response($success_res);
                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return new WP_REST_Response(['success' => false, 'message' => 'Something went wrong while updating webhook', 'error' => $e->getMessage()]);
                }
        }

        //This will return the custom domain of the website
        public function get_custom_domain($request)
        {
                try {
                        $body = file_get_contents('php://input');
                        $body = json_decode($body, true);
                        $data = [
                                'success' => true,
                                'domain' => get_site_url()
                        ];
                        return new WP_REST_Response($data);
                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return new WP_REST_Response(['success' => false, 'message' => 'Something went wrong while generating custom domain', 'error' => $e->getMessage()]);
                }
        }

        //This function will disconnect the brand from the plugin
        public function disconnect_brand($request)
        {
                try {
                        $body = file_get_contents('php://input');
                        $body = json_decode($body, true);

                        if (get_option('MARKOPOLO_API_KEY'))
                                update_option('MARKOPOLO_API_KEY', '');
                        if (get_option('MARKOPOLO_API_KEY_IV'))
                                update_option('MARKOPOLO_API_KEY_IV', '');
                        if (get_option('brandId'))
                                update_option('brandId', '');

                        $data = ['success' => true, 'message' => 'Brand disconnected successfully', 'error' => '', 'data' => []];
                        return new WP_REST_Response($data);

                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return new WP_REST_Response(['success' => false, 'message' => 'Something went wrong while disconnecting brand', 'error' => $e->getMessage()]);

                }
        }


}