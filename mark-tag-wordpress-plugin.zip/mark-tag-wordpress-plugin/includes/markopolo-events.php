<?php
include_once 'helpers.php';
include_once 'logger.php';

//This Class will listen to the events set up by admin and emitted by woocommerce and send it to markopolo server
class Markopolo_Events
{

        private $logger;

        public function __construct()
        {
                $this->logger = new Logger();

        }

        public function register()
        {
                try {
                        // Hook event handlers
                        //Check whether these events are added by user

                        add_action('woocommerce_add_to_cart', [$this, 'handle_add_to_carts'], 9, 6);

                        add_action('woocommerce_checkout_init', [$this, 'handle_checkout_init'], 10);

                        add_action('woocommerce_after_checkout_validation', [$this, 'handle_add_payment_info'], 10, 2);

                        add_action('woocommerce_new_order', [$this, 'handle_order_processed'], 20, 1);

                        add_action('woocommerce_after_cart_item_quantity_update', [$this, 'handle_update_cart'], 10, 4);
                        // add_action('wp', [$this, 'handle_page_visit'], 12);

                } catch (Exception $e) {
                        return false;
                }
        }

        public function handle_add_to_carts($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data)
        {
                try {

                        if (!get_option('AddToCart'))
                                return;

                        $product = wc_get_product($product_id);

                        $name = $product->get_name();
                        $variant = $variation;
                        $price = $product->get_price();

                        $data = [];
                        // Format data
                        $data[] = [
                                'id' => $product_id,
                                'name' => $name,
                                'variant' => $variant,
                                'quantity' => $quantity,
                                'price' => $price
                        ];
                        $this->logger->log("add to cart");

                        $this->send_event_to_markopolo('AddToCart', $data, []);

                } catch (Exception $e) {
                        return false;
                }

        }


        public function handle_checkout_init()
        {

                try {
                        if (!get_option('BeginCheckout')) {
                                $this->logger->log("BeginCheckout not enabled");
                                echo "BeginCheckout not enabled";
                                return;
                        }
                        $cart = WC()->cart;
                        $shipping = WC()->cart->get_shipping_total();
                        $tax = WC()->cart->get_cart_contents_tax() + WC()->cart->get_shipping_tax();

                        $data = [];
                        foreach ($cart->get_cart() as $item => $values) {

                                $product = $values['data'];

                                $data[] = [
                                        'id' => $product->get_id(),
                                        'name' => $product->get_name(),
                                        'variant' => wc_get_formatted_variation($product, true),
                                        'quantity' => $values['quantity'],
                                        'price' => $values['line_total'] / $values['quantity'],
                                ];

                        }

                        $additionalData = [
                                'shipping_cost' => $shipping,
                                'tax' => $tax,
                                'value' => $cart->get_cart_contents_total() + $shipping + $tax,
                                'currency' => get_woocommerce_currency()
                        ];



                        $this->send_event_to_markopolo('BeginCheckout', $data, $additionalData);
                } catch (Exception $e) {
                        return false;
                }
        }

        public function handle_add_payment_info($data, $err)
        {
                if (!get_option('AddPaymentInfo') || !isset($data['payment_method']))
                        return;

                if ($data['payment_method'] == 'cod')
                        return;

                $additional_data = [
                        'currency' => get_woocommerce_currency(),
                        'payment_method' => $data['payment_method'],
                        'phone' => $data['billing_phone']
                ];

                $cart = WC()->cart;

                $products = [];
                foreach ($cart->get_cart() as $item => $values) {

                        $product = $values['data'];

                        $products[] = [
                                'id' => $product->get_id(),
                                'name' => $product->get_name(),
                                'quantity' => $values['quantity'],
                                'price' => $values['line_total'] / $values['quantity'],
                        ];

                }

                $this->send_event_to_markopolo('AddPaymentInfo', $products, $additional_data);
        }

        public function handle_order_processed($order_id)
        {
                try {
                        if (!get_option('Purchase'))
                                return;

                        $order = wc_get_order($order_id);

                        $order_total = $order->get_total();

                        $shipping = $order->get_shipping_total();

                        // Get total tax amount
                        $tax = $order->get_total_tax();

                        $data = [];
                        // foreach ($cart->get_cart() as $item => $values) {

                        //         $product = $values['data'];

                        //         $data[] = [
                        //                 'id' => $product->get_id(),
                        //                 'name' => $product->get_name(),
                        //                 'variant' => wc_get_formatted_variation($product, true),
                        //                 'quantity' => $values['quantity'],
                        //                 'price' => $values['line_total'] / $values['quantity'],
                        //         ];

                        // }
                        foreach ($order->get_items() as $item_id => $item) {

                                $product = $item->get_product();

                                $product_price = $product->get_price();
                                $product_id = $product->get_id();
                                $product_name = $product->get_name();
                                $product_qty = $item->get_quantity();

                                $data[] = [
                                        'id' => $product_id,
                                        'name' => $product_name,
                                        'quantity' => $product_qty,
                                        'price' => $product_price,
                                ];

                        }
                        $additionalData = [
                                'shipping_cost' => $shipping,
                                'tax' => $tax,
                                'value' => $order_total,
                                'currency' => get_woocommerce_currency(),
                                'transaction_id' => $order->get_transaction_id()
                        ];

                        $this->send_event_to_markopolo('Purchase', $data, $additionalData);
                } catch (Exception $e) {

                        return false;
                }
        }

        //If user directly visits checkout page
        public function handle_page_visit()
        {
                try {
                        //checking for user agent
                       
                        global $post;
                        $page_url = get_permalink($post->ID);
                        $referer = $_SERVER['HTTP_REFERER'] ?? '';
                        if (!str_ends_with($page_url, 'checkout/'))
                                return false;
                        else if (str_ends_with($page_url, 'checkout/') && str_ends_with($referer, 'checkout/'))
                                return false;
                        else if (str_ends_with($page_url, 'checkout/') && str_ends_with($referer, 'cart/'))
                                return false;

                        $this->handle_checkout_init();
                } catch (Exception $e) {
                        return false;
                }
        }
        public function handle_update_cart($cart_item_key, $quantity, $old_quantity, $cart)
        {
                try {
                        if (!get_option('AddToCart'))
                                return;
                        $cart = WC()->cart;
                        $shipping = WC()->cart->get_shipping_total();
                        $tax = WC()->cart->get_cart_contents_tax() + WC()->cart->get_shipping_tax();

                        $data = [];
                        foreach ($cart->get_cart() as $item => $values) {

                                $product = $values['data'];

                                $data[] = [
                                        'id' => $product->get_id(),
                                        'name' => $product->get_name(),
                                        'variant' => wc_get_formatted_variation($product, true),
                                        'quantity' => $values['quantity'],
                                        'price' => $values['line_total'] / $values['quantity'],
                                ];

                        }

                        $additionalData = [
                                'shipping_cost' => $shipping,
                                'tax' => $tax,
                                'value' => $cart->get_cart_contents_total() + $shipping + $tax,
                                'currency' => get_woocommerce_currency()
                        ];



                        $this->send_event_to_markopolo('AddToCart', $data, $additionalData);


                } catch (Exception $e) {
                        return false;
                }
        }
        private function send_event_to_markopolo($event, $product, $additionalData)
        {
                try {
                        $markopolo_helper_1 = new Markolopolo_Helper();
                        $cf_data = $markopolo_helper_1->get_cf_trace();

                        $ip = $cf_data['ip'] ?? '';
                        $country = $cf_data['loc'] ?? '';
                        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
                        $referer = $_SERVER['HTTP_REFERER'] ?? '';
                        global $post;
                        $muid = $_COOKIE['_muid'] ?? "";
                        $page_url = get_permalink($post->ID);
                        $site_url = get_site_url();
                        // if ($page_url === "$site_url/2023/07/09/hello-world/" && $event != 'ViewContent' && $event != 'Purchase' && $event != 'AddPurchaseInfo' && $event != 'AddToCart')
                        //         return false;
                        if ($event == 'ViewContent' || $event == 'BeginCheckout') {
                                if (str_ends_with($page_url, 'hello-world/'))
                                        return false;
                                if ($user_agent && (str_contains($_SERVER['HTTP_USER_AGENT'], 'ELB-HealthChecker'))) {
                                        return;
                                }

                                // Check referer 
                                if (empty($_SERVER['HTTP_REFERER']) || !(str_starts_with($_SERVER['HTTP_REFERER'], $site_url))) {
                                        return;
                                }

                                if (empty($page_url) || !str_starts_with($page_url, $site_url)) {
                                        return;
                                }
                        } else if ($event == "AddToCart" || $event == "AddPaymentInfo" || $event == "Purchase") {
                                if (str_ends_with($page_url, 'hello-world/'))
                                        $page_url = $referer;
                                if (!$page_url)
                                        $page_url = $referer;
                        }

                        $email = "";
                        if (is_user_logged_in()) {

                                $user = wp_get_current_user();
                                $email = $user->user_email;
                        }



                        $data = [
                                'x-cf-ip' => $ip,
                                'x-cf-loc' => $country,
                                'user_agent' => $user_agent,
                                'referer' => $referer,
                                'pageUrl' => $page_url,
                                'event' => $event,
                                'email' => $email,
                                'muid' => $muid
                        ];
                        if (!empty($additionalData)) {
                                $data = array_merge($data, $additionalData);
                        }
                        if (!empty($product)) {
                                $data['products'] = $product;
                        }

                        $args = [
                                'headers' => [
                                        'Content-Type' => 'application/json; charset=utf-8',
                                ],
                                'body' => json_encode($data)
                        ];
                        $is_brand_connected = get_option('brandId');
                        if ($is_brand_connected)
                                wp_remote_post('https://tag-api.markopolo.ai/webhook/woocommerce-events-webhook', $args);
                        return true;
                } catch (Exception $e) {
                        $this->logger->log($e->getMessage());
                        return false;
                }
        }

}