<?php
// Helper functions
class Markolopolo_Helper
{
        public function is_woo_active_for_markopolo()
        {
                return class_exists('WooCommerce');
        }

        //This will get location and country name of the user
        public function get_cf_trace()
        {
                try {
                        $ip = WC_Geolocation::get_ip_address();

                        //Make get request to ip-api.com to get location and country name
                        $result = file_get_contents('http://ip-api.com/json/' . $ip);
                        //decode response
                        $result = json_decode($result, true);
                        $location = $result['countryCode'];


                        $data = ['loc' => $location, 'ip' => $ip];
                        return $data;

                } catch (Exception $e) {
                        return false;
                }

        }

        //Function to encrypt the API key
        //Checking Role of the user, only if the user is admin, the API key will be encrypted
        public function encrypt_markopolo_api_server_key($api_key)
        {
                try {
                        if (current_user_can('administrator')) {
                                // Hash the key
                                $hashed_key = hash('sha256', $api_key);
                                // Create an encryption key 
                                $encryption_key = '76e3ac8898c6cacd94322842f94a5ffdbab9e05b17c5c8174eb59fe12d18ca95';
                                // Generate a random IV (Initialization Vector)
                                $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
                                // Encrypt and store the API key

                                $encrypted_api_key = openssl_encrypt($hashed_key, 'aes-256-cbc', $encryption_key, 0, $iv);
                                return [
                                        'encrypted_key' => $encrypted_api_key,
                                        'iv' => $iv,

                                ];
                        } else {
                                return false;
                        }

                } catch (Exception $e) {
                        return false;
                }

        }

        // Function to retrieve the decrypted API key
        // Checking Role of the user, only if the user is admin, the API key will be decrypted
        public function get_decrypted_api_key($encrypted_api_key, $iv)
        {
                try {
                        if (current_user_can('administrator')) {

                                $encryption_key = '76e3ac8898c6cacd94322842f94a5ffdbab9e05b17c5c8174eb59fe12d18ca95';

                                $api_key = openssl_decrypt($encrypted_api_key, 'aes-256-cbc', $encryption_key, 0, $iv);

                                return $api_key;
                        } else {
                                return false;
                        }
                } catch (Exception $e) {
                        return false;
                }
        }



        //Connect Markopolo to Woocommerce, make an API call to Markopolo server using api key
        public function authRequest()
        {
                try {

                        //checking if brandId is set, if not set, then only admin can connect to markopolo
                        if (!get_option('brandId') && current_user_can('administrator')) {

                                if (!get_option('MARKOPOLO_SERVER_API_KEY') || !get_option('MARKOPOLO_API_KEY') || !get_option('MARKOPOLO_API_KEY_IV')) {
                                        //generate hashed api key and then encrypt it
                                        $api_key = bin2hex(random_bytes(16));
                                        update_option('MARKOPOLO_SERVER_API_KEY', $api_key);

                                        $key_data = $this->encrypt_markopolo_api_server_key($api_key);
                                        update_option('MARKOPOLO_API_KEY', $key_data['encrypted_api_key']);
                                        update_option('MARKOPOLO_API_KEY_IV', $key_data['iv']);
                                } else {
                                        $api_key = get_option('MARKOPOLO_SERVER_API_KEY');
                                }

                                //get store url
                                $store_url = get_bloginfo('url');
                                $url = "https://api.markopolo.ai/v3.0/woocommerce/auth?storeUrl=${store_url}&apiKey=$api_key";

                        } else {
                                $url = `https://app.markopolo.ai/brand/details`;
                        }
                        return $url;

                } catch (Exception $e) {
                        return false;
                }
        }

        public function disconnect()
        {
                try {

                        $api_key = get_option('MARKOPOLO_SERVER_API_KEY');

                        // Make an API call to Markopolo server to disconnect
                        $url = "https://api.markopolo.ai/v3.0/woocommerce/disconnect-woocommerce-from-plugin";
                        $data = [
                                'apiKey' => $api_key
                        ];
                        // Create the request arguments
                        $args = [
                                'headers' => [
                                        'Content-Type' => 'application/json; charset=utf-8',
                                ],
                                'body' => json_encode($data)
                        ];
                        $response = wp_remote_post($url, $args);
                        $response_body = wp_remote_retrieve_body($response);
                        $response_body = json_decode($response_body);
                        if ($response_body && $response_body->success == 'success') {
                                return true;
                        } else {
                                return false;
                        }
                } catch (Exception $e) {
                        return false;
                }
        }
}