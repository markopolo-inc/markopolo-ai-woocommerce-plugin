<?php

define('MARKOPOLO_LOG_PATH', WP_CONTENT_DIR . '/plugins/mark-tag-wordpress-plugin/log/logger.log');

class Logger
{
        private $logfile;

        public function __construct()
        {
                $this->logfile = MARKOPOLO_LOG_PATH;
        }

        public function log($msg)
        {
                error_log($msg, 3, $this->logfile);
        }

}

// Usage
$logger = new Logger();
$logger->log('My message');
?>