<?php
// API functions 

function send_event()
{
        // ...
}

function register_endpoints()
{
        // ...
}