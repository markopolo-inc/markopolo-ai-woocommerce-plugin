<?php
include_once('helpers.php');

//if user confirms disconnection of brand, then delete all the options and sent request to server to delete wocommerce brand info
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm'])) {

        $markopolo_helper = new Markolopolo_Helper();
        $success = $markopolo_helper->disconnect();
        if ($success) {
                update_option('brandId', '');
                update_option('MARKOPOLO_API_KEY', '');
                update_option('MARKOPOLO_API_KEY_IV', '');
                

                // Output JavaScript to hide the alert on the client side
                echo '<script>';
                echo 'document.addEventListener("DOMContentLoaded", function() {';
                echo 'document.getElementById("mtag-plugin-close-alert").addEventListener("click", function() {';
                echo 'var alertBox = document.querySelector(".mtag-plugin-custom-alert");';
                echo 'alertBox.style.display = "none";';
                echo '});';
                echo '});';
                echo '</script>';

                // Display the success message and alert box
                echo '<div class="mtag-plugin-custom-alert">';
                echo '<p>Markopolo disconnected Successfully</p>';
                echo '<button id="mtag-plugin-close-alert">Close</button>';
                echo '</div>';
        } else {
                // Display the failure message and alert box
                echo '<div class="mtag-plugin-custom-alert">';
                echo '<p>Failed to Disconnect</p>';
                echo '<button id="mtag-plugin-close-alert">Close</button>';
                echo '</div>';
        }
}


?>
<html>

<head>
        <style>

                .mtag-plugin-container-3esdz{
                  border: 1px solid #c5c5c5;
                  max-width: 800px;
                  margin-top: 2rem;
                  padding: 2rem 1.5rem;
                  border-radius: 12px;
                }

                .mtag-plugin-header {
                  display: flex;
                  align-items: center;
                }

                .mtag-plugin-header h1 {
                  margin-left: 0.5rem;
                }

                .mtag-plugin-logo {
                  width: 45px;
                }

                .mtag-plugin-description {
                  font-size: 1.1rem;
                }

                #settings {
                        background: blue;
                        color: white;
                        padding: 10px 20px;
                        border-radius: 4px;
                        cursor: pointer;
                }

                .mtag-plugin-custom-alert {
                        background-color: #f2dede;
                        color: #a94442;
                        border: 1px solid #a94442;
                        padding: 15px;
                        margin: 20px 0;
                        border-radius: 4px;
                        max-width: 800px;
                }

                #mtag-plugin-close-alert {
                        background-color: #a94442;
                        color: #fff;
                        border: none;
                        padding: 5px 10px;
                        border-radius: 4px;
                        cursor: pointer;
                }

                #mtag-plugin-close-alert:hover {
                        background-color: #761c19;
                }

                .custom-div {
                        background-color: #f2f2f2;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        padding: 10px;
                        margin: 10px;
                        text-align: center;
                        width: auto;
                        /* Remove any explicit width setting */
                        display: inline-block;
                        /* Make the div shrink to its content */
                }

                .custom-div span {
                        font-size: 16px;
                        font-weight: bold;
                        color: #0073e6;
                }

                .custom-div button {
                        font-size: 12px;
                        padding: 4px 8px;
                }
        </style>
</head>

<body>
    <div class="mtag-plugin-container-3esdz">
        <div class="mtag-plugin-header">
                <img src="https://app.markopolo.ai/assets/logo-191aed1a.svg" class="mtag-plugin-logo">
                <h1>Markopolo.ai</h1>
        </div>

        <p class="mtag-plugin-description">
                Capture every event, & get back every lost audience from all channels. Seamlessly integrate MarkTag with woocommerce to track all your conversions.
        </p>

        <!-- When user clicks on the Connect to Markopolo Button, it will redirect to markopolo server  -->
        <?php
        if (isset($_POST['setting'])) {
                $markopolo_helper = new Markolopolo_Helper();
                $url = $markopolo_helper->authRequest();

                if ($url) {
                        wp_redirect($url);
                }
        }

        // When User clicks on disconnect button, it will ask for confirmation
        if (isset($_POST['disconnect'])) {
                ?>
                <div class="mtag-plugin-custom-alert">
                        <p>Disconnecting may disrupt the MarkTag workflow associated with this site.</p>
                        <form method="post">
                                <input type="submit" name="confirm" class="button" value="Confirm" />
                                <input type="submit" name="cancel" class="button" value="Cancel" />
                        </form>
                </div>
                <?php
        }
        ?>



        <!-- If brand already connected , it shows the name, else it will show button to connect with markopolo -->
        <?php
        $brandName = get_option('brandId');

        if (!$brandName) {
                ?>
                <form method="post">
                        <input type="submit" name="setting" class="button" value="Connect To Markopolo" />
                </form>
                <?php
        } else {
                ?>
                <div class="custom-div">
                        <span><?php echo $brandName ?></span>
                </div>
                <?php
        }
        ?>

        <!-- Show disconnect Button if brand is connected -->
        <?php
        if ($brandName) {
                ?>
                <form method="post">
                        <input type="submit" name="disconnect" class="button" value="Disconnect" />
                </form>
                <?php
        }
        ?>
    </div>



        <script>
                document.addEventListener("DOMContentLoaded", function () {
                        document.querySelector('#mtag-plugin-close-alert').addEventListener("click", function () {
                                var alertBox = document.querySelector('.mtag-plugin-custom-alert');
                                alertBox.style.display = 'none';
                        });
                });
        </script>
</body>

</html>