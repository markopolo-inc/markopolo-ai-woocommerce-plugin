<?php
define('dev', true);
?>